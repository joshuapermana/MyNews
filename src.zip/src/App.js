/* eslint-disable prettier/prettier */
import React, { Component } from 'react';
import { PersistGate } from 'redux-persist/integration/react'; 
import { Provider } from 'react-redux'; 
import { store, persistor } from './redux/store'; 
import { NavigationContainer } from '@react-navigation/native';
import Routes from './route';
import '../global.js';
// import codePush from "react-native-code-push";

class App extends Component {
  componentDidMount() {
    // do stuff while splash screen is shown
    // After having done stuff (such as async tasks) hide the splash screen
  }

  render() {
    return (
      // Redux: Global Store
      <Provider store={store}>
        <PersistGate loading={null} persistor={persistor}>
          <NavigationContainer>
            <Routes />
          </NavigationContainer>
        </PersistGate>
      </Provider>
    );
  }
}
// let codePushOptions = { checkFrequency: codePush.CheckFrequency.ON_APP_START, installMode: codePush.InstallMode.IMMEDIATE };
// App = codePush(codePushOptions)(App);
export default App;