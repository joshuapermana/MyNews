
const initialState = {
  loggedIn: false,
  regist: false,
  uid: null,
  email: null,
  fullname: null,
  phone: null,
  photo: false,
  newUser: false,
};


const authReducer = (state = initialState, action) => {
  switch (action.type) {
    
    case 'LOGIN': {
      const { uid,email } = action.payload;
      return {
        ...state,
        ...{
          uid,
          email,
          loggedIn: true,
          regist: false,
        },
      };
    }
    
    case 'REGISTER': {
      const { email, uid } = action.payload;
      return {
        ...state,
        ...{
          token,
          regist: true,
          newUser: true,
        },
      };
    }
    
    case 'ACCOUNT': {
      const { displayName, phoneNumber, photo } = action.payload;
      return {
        ...state,
        ...{
          fullname: displayName,
          phone: phoneNumber,
          photo: photo,
        },
      };
    }
    
    case 'LOGOUT': {
      return {
        ...state,
        ...{
          loggedIn: false,
        },
      };
    }
    default: {
      return state;
    }
  }
};


export default authReducer;
